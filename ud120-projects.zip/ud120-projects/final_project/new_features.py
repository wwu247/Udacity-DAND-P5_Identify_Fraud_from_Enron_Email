## These new features were not included in the final poi_id.py file since they did not result in meaningful improvements to the precision and recall scores of the machine learning classifier.

#'poi_email_ratio'
efeatures = ['shared_receipt_with_poi', 'from_poi_to_this_person', 'from_this_person_to_poi', 'to_messages', 'from_messages']
for record in data_dict:
	person = data_dict[record]
	is_valid = True
	for efeature in efeatures:
		if person[efeature] == 'NaN':
			is_valid = False
	if is_valid:
		poi_emails = person['shared_receipt_with_poi'] + person['from_poi_to_this_person'] + person['from_this_person_to_poi']
		total_emails = person['to_messages'] + person['from_messages']
		person['poi_email_ratio'] = float(poi_emails) / total_emails
	else:
		person['poi_email_ratio'] = 'NaN'
features_list += ['poi_email_ratio']

#'assets'
afeatures = ['exercised_stock_options', 'total_stock_value', 'bonus', 'salary']
for record in data_dict:
	person = data_dict[record]
	is_valid = True
	for afeature in afeatures:
		if person[afeature] == 'NaN':
			is_valid = False
	if is_valid:
		person['assets'] = person['exercised_stock_options'] + person['total_stock_value'] + person['bonus'] + person['salary']
	else:
		person['assets'] = 'NaN'
features_list += ['assets']

#'tsvb_salary_ratio'
rfeatures = ['total_stock_value', 'bonus', 'salary']
for record in data_dict:
	person = data_dict[record]
	is_valid = True
	for rfeature in rfeatures:
		if person[rfeature] == 'NaN':
			is_valid = False
	if is_valid:
		tsvb = person['total_stock_value'] + person['bonus']
		person['tsvb_salary_ratio'] =  float(tsvb) / person['salary']
	else:
		person['tsvb_salary_ratio'] = 'NaN'
features_list += ['tsvb_salary_ratio']